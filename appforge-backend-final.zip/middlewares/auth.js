const { findUserByApiKey } = require('./models/User');

// Autenticación por API Key (para desarrolladores)
async function authenticateApiKey(req, res, next) {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey) return res.status(401).json({ error: 'Missing API Key' });
  const user = await findUserByApiKey(apiKey);
  if (!user) return res.status(401).json({ error: 'Invalid API Key' });
  req.user = user;
  next();
}

// Autenticación por token de sesión (para usuarios anónimos)
function authenticateSessionToken(req, res, next) {
  const token = req.headers['x-session-token'];
  if (!token) return res.status(401).json({ error: 'Se requiere token de sesión' });
  const session = global.sessions.get(token);
  if (!session || session.expires < Date.now()) {
    global.sessions.delete(token);
    return res.status(401).json({ error: 'Token inválido o expirado' });
  }
  req.session = session;
  next();
}

module.exports = { authenticateApiKey, authenticateSessionToken };