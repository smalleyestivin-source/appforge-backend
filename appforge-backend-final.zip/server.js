require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const path = require('path');
const { openDb } = require('./db/database');
const { initBuildQueue } = require('./services/buildQueue');
const { startCleanupScheduler } = require('./services/cleanup');
const limiter = require('./middlewares/rateLimiter');
const errorHandler = require('./middlewares/errorHandler');
const apkRoutes = require('./routes/apk');

const app = express();
const PORT = process.env.PORT || 3000;

// Sessions globales (en memoria)
global.sessions = new Map();

// Middleware
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: '*',
  methods: ['GET','POST','PUT','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization','x-session-token','x-api-key']
}));
app.options('*', cors());
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(limiter);

// Endpoint: crear sesión (para usuarios sin cuenta)
app.post('/api/session', (req, res) => {
  const { nanoid } = require('nanoid');
  const token = nanoid(32);
  global.sessions.set(token, {
    token,
    createdAt: Date.now(),
    expires: Date.now() + (24 * 60 * 60 * 1000)
  });
  res.json({ token, expiresIn: 86400 });
});

// Endpoint: status
app.get('/api/status', (req, res) => {
  res.json({
    status: 'ok',
    version: '5.0.0',
    uptime: process.uptime(),
    queued: global.sessions.size
  });
});

// Endpoint: verificar si APK está listo
app.get('/api/build/:sessionId/status', (req, res) => {
  const apkPath = path.join(__dirname, 'downloads', req.params.sessionId + '.apk');
  const fs = require('fs-extra');
  if (fs.pathExistsSync(apkPath)) {
    res.json({ ready: true, url: '/downloads/' + req.params.sessionId + '.apk' });
  } else {
    res.json({ ready: false });
  }
});

// Servir APKs descargables
app.use('/downloads', express.static(path.join(__dirname, 'downloads')));

// Rutas APK
app.use('/api', apkRoutes);

// Error handler
app.use(errorHandler);

// Iniciar
async function start() {
  await openDb();
  initBuildQueue();
  startCleanupScheduler();
  app.listen(PORT, () => {
    console.log('AppForge Backend v5.0 corriendo en puerto ' + PORT);
  });
}

start().catch(console.error);
