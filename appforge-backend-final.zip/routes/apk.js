const express = require('express');
const router = express.Router();
const multer = require('multer');
const fs = require('fs-extra');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { authenticateSessionToken } = require('./middlewares/auth');
const { buildApk } = require('./services/apkBuilder');
const { scanProject } = require('./services/securityScanner');
const { enqueueBuild } = require('./services/buildQueue');

const upload = multer({ dest: '/tmp/uploads/' });

// Endpoint para generar APK (para usuarios anónimos con token)
router.post('/generate-apk', authenticateSessionToken, upload.single('project'), async (req, res) => {
  try {
    const sessionId = uuidv4();
    const extractPath = path.join('/tmp', `project-${sessionId}`);
    await fs.ensureDir(extractPath);
    
    // Extraer ZIP
    const unzipper = require('unzipper');
    await fs.createReadStream(req.file.path).pipe(unzipper.Extract({ path: extractPath })).promise();
    
    // Escaneo de seguridad
    const scan = await scanProject(extractPath);
    if (!scan.safe) {
      await fs.remove(extractPath);
      return res.status(400).json({ error: 'Proyecto inseguro', details: scan.issues });
    }
    
    // Encolar construcción
    const metadata = { 
      name: req.body.name || 'App', 
      backgroundColor: req.body.backgroundColor || '#ffffff' 
    };
    
    enqueueBuild(async () => {
      const apkPath = await buildApk(extractPath, metadata, sessionId);
      const publicDir = path.join(__dirname, '../downloads');
      await fs.ensureDir(publicDir);
      const destPath = path.join(publicDir, `${sessionId}.apk`);
      await fs.copy(apkPath, destPath);
      await fs.remove(extractPath);
      await fs.remove(req.file.path);
      return `/downloads/${sessionId}.apk`;
    }).catch(err => console.error('Build error:', err));
    
    res.json({ success: true, sessionId });
    
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Endpoint para descargar APK
router.get('/downloads/:sessionId.apk', async (req, res) => {
  const filePath = path.join(__dirname, '../downloads', `${req.params.sessionId}.apk`);
  if (await fs.pathExists(filePath)) {
    res.download(filePath);
  } else {
    res.status(404).json({ error: 'APK no listo o no existe' });
  }
});

module.exports = router;