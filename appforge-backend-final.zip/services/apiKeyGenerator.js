const { nanoid } = require('nanoid');
const { findUserByApiKey } = require('./models/User');

const PREFIX = 'af_';

async function generateUniqueApiKey() {
  let unique = false;
  let apiKey = '';
  let attempts = 0;
  while (!unique && attempts < 10) {
    apiKey = PREFIX + nanoid(40);
    const existing = await findUserByApiKey(apiKey);
    if (!existing) unique = true;
    attempts++;
  }
  if (!unique) throw new Error('Could not generate unique API key');
  return apiKey;
}

module.exports = { generateUniqueApiKey };