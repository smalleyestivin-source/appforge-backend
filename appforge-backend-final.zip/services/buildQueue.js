let pendingJobs = [];
let isProcessing = false;

function initBuildQueue() {
  console.log('🐂 Cola de builds inicializada (modo memoria)');
}

async function enqueueBuild(jobFn) {
  return new Promise((resolve, reject) => {
    pendingJobs.push({ jobFn, resolve, reject });
    processQueue();
  });
}

async function processQueue() {
  if (isProcessing || pendingJobs.length === 0) return;
  isProcessing = true;
  
  while (pendingJobs.length > 0) {
    const { jobFn, resolve, reject } = pendingJobs.shift();
    try {
      const result = await jobFn();
      resolve(result);
    } catch (err) {
      reject(err);
    }
    await new Promise(r => setTimeout(r, 5000));
  }
  isProcessing = false;
}

module.exports = { initBuildQueue, enqueueBuild };