const fs = require('fs-extra');
const path = require('path');

const BLACKLIST_EXT = ['.php', '.asp', '.jsp', '.py', '.exe', '.dll', '.so', '.bat', '.sh', '.ps1'];
const SUSPICIOUS_PATTERNS = ['eval(', 'document.write(', 'setTimeout("', 'setInterval("', 'new Function('];

async function scanProject(projectPath) {
  const issues = [];
  let totalSize = 0;
  let fileCount = 0;
  const MAX_SIZE = parseInt(process.env.MAX_FILE_SIZE) || 50 * 1024 * 1024;
  const MAX_FILES = parseInt(process.env.MAX_FILES_PER_PROJECT) || 1000;
  
  const scanDir = async (dir) => {
    const entries = await fs.readdir(dir);
    for (const entry of entries) {
      const fullPath = path.join(dir, entry);
      const stat = await fs.stat(fullPath);
      if (stat.isDirectory()) {
        await scanDir(fullPath);
      } else {
        fileCount++;
        totalSize += stat.size;
        if (totalSize > MAX_SIZE) issues.push(`Tamaño total excede ${MAX_SIZE/1024/1024}MB`);
        if (fileCount > MAX_FILES) issues.push(`Demasiados archivos (>${MAX_FILES})`);
        const ext = path.extname(entry).toLowerCase();
        if (BLACKLIST_EXT.includes(ext)) issues.push(`Archivo prohibido: ${entry}`);
        if (entry.endsWith('.html') || entry.endsWith('.js')) {
          const content = await fs.readFile(fullPath, 'utf-8');
          for (const pattern of SUSPICIOUS_PATTERNS) {
            if (content.includes(pattern)) {
              issues.push(`Patrón sospechoso en ${entry}: ${pattern}`);
            }
          }
        }
      }
    }
  };
  
  await scanDir(projectPath);
  return { safe: issues.length === 0, issues };
}

module.exports = { scanProject };