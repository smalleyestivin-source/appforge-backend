const fs = require('fs-extra');
const path = require('path');

const TEMP_DIRS = ['/tmp', path.join(__dirname, '../uploads'), path.join(__dirname, '../downloads')];
const MAX_AGE_MS = 24 * 60 * 60 * 1000;

async function cleanupOldFiles() {
  const now = Date.now();
  for (const dir of TEMP_DIRS) {
    if (!await fs.pathExists(dir)) continue;
    const files = await fs.readdir(dir);
    for (const file of files) {
      const fullPath = path.join(dir, file);
      const stat = await fs.stat(fullPath);
      if (now - stat.mtimeMs > MAX_AGE_MS) {
        await fs.remove(fullPath);
        console.log(`🧹 Eliminado archivo antiguo: ${fullPath}`);
      }
    }
  }
}

function startCleanupScheduler() {
  setInterval(cleanupOldFiles, parseInt(process.env.CLEANUP_INTERVAL_MS) || 86400000);
  cleanupOldFiles();
}

module.exports = { startCleanupScheduler };